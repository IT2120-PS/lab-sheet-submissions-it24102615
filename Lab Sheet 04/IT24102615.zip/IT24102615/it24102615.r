getwd()

setwd("C:\\Users\\ASUS\\Desktop\\PS_Lab_04\\IT24102615")

#Exercise
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)

boxplot(branch_data$Sales_X1, main="Boxplot of Sales", outline=TRUE, col="lightblue", horizontal=TRUE)

# Five number summary
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
